import os
import json
from typing import Dict, TypedDict, Any, List
from langgraph.graph import StateGraph, END
from langchain_groq import ChatGroq
from langchain_core.messages import SystemMessage, HumanMessage
from schemas import AIAnalysisResult, ExtractionResponse, RootCauseItem, CAPAItem

class GraphState(TypedDict):
    input_text: str
    extracted_info: Dict[str, Any]
    evidence_gaps: List[str]
    causes: List[Dict[str, Any]]
    capas: List[Dict[str, Any]]
    validation_status: bool

# Updated to supported model
llm = ChatGroq(model_name="llama3-70b-8192", temperature=0.1)

def document_processing(state: GraphState):
    return {"input_text": state["input_text"].strip()}

def incident_extraction(state: GraphState):
    sys_msg = SystemMessage(content="""You are a pharmaceutical QA expert. 
Extract incident details into JSON: deviation_id, title, description, product_name, batch_number, manufacturing_stage, expected_result, actual_result, missing_info (list of fields not found).""")
    msg = llm.invoke([sys_msg, HumanMessage(content=state["input_text"])])
    try:
        data = json.loads(msg.content[msg.content.find('{'):msg.content.rfind('}')+1])
    except Exception:
        data = {"missing_info": ["Failed to parse text properly."]}
    return {"extracted_info": data}

def evidence_assessment(state: GraphState):
    sys_msg = SystemMessage(content="Analyze the incident and list critical missing pharmaceutical evidence as a JSON array of strings.")
    msg = llm.invoke([sys_msg, HumanMessage(content=str(state["extracted_info"]))])
    try:
        gaps = json.loads(msg.content[msg.content.find('['):msg.content.rfind(']')+1])
    except Exception:
        gaps = []
    return {"evidence_gaps": gaps}

def root_cause_analysis(state: GraphState):
    sys_msg = SystemMessage(content="Perform Root Cause Analysis. Output JSON array of cause objects: {description, evidence, confidence, category, status:'Potential'}")
    msg = llm.invoke([sys_msg, HumanMessage(content=str(state["extracted_info"]))])
    try:
        causes = json.loads(msg.content[msg.content.find('['):msg.content.rfind(']')+1])
    except Exception:
        causes = []
    return {"causes": causes}

def capa_recommendation(state: GraphState):
    sys_msg = SystemMessage(content="Generate CAPA based on causes. Output JSON array: {action_type, description, priority, department}")
    msg = llm.invoke([sys_msg, HumanMessage(content=str(state["causes"]))])
    try:
        capas = json.loads(msg.content[msg.content.find('['):msg.content.rfind(']')+1])
    except Exception:
        capas = []
    return {"capas": capas}

def validation(state: GraphState):
    return {"validation_status": True}

def build_graph():
    workflow = StateGraph(GraphState)
    workflow.add_node("process", document_processing)
    workflow.add_node("extract", incident_extraction)
    workflow.add_node("evidence", evidence_assessment)
    workflow.add_node("rca", root_cause_analysis)
    workflow.add_node("capa", capa_recommendation)
    workflow.add_node("validate", validation)
    
    workflow.set_entry_point("process")
    workflow.add_edge("process", "extract")
    workflow.add_edge("extract", "evidence")
    workflow.add_edge("evidence", "rca")
    workflow.add_edge("rca", "capa")
    workflow.add_edge("capa", "validate")
    workflow.add_edge("validate", END)
    
    return workflow.compile()

graph_app = build_graph()

def get_demo_fallback() -> AIAnalysisResult:
    return AIAnalysisResult(
        extracted_data=ExtractionResponse(
            deviation_id="DEV-2026-042",
            title="Low Yield in API Crystallization",
            description="Yield below target range during crystallization and Nutsche filtration.",
            product_name="Demo API-01",
            batch_number="DEMO-2026-001",
            manufacturing_stage="Crystallization and Filtration",
            expected_result="170 - 185 kg",
            actual_result="145 kg",
            missing_info=["Filtration vacuum pump maintenance log"]
        ),
        potential_causes=[
            RootCauseItem(
                description="Vacuum pump efficiency loss leading to prolonged filtration time",
                evidence="Operator reported strange noise from vacuum pump",
                confidence="High",
                category="Machine",
                status="Potential"
            )
        ],
        capas=[
            CAPAItem(
                action_type="Corrective",
                description="Inspect and service vacuum pump rebuild assembly",
                priority="High",
                department="Maintenance"
            )
        ],
        missing_evidence=["Vacuum pump maintenance log", "Mother liquor analytical batch record"]
    )

def run_investigation_workflow(text: str) -> AIAnalysisResult:
    api_key = os.getenv("GROQ_API_KEY")
    if not api_key or api_key == "your_groq_api_key_here":
        return get_demo_fallback()
        
    try:
        res = graph_app.invoke({"input_text": text})
        return AIAnalysisResult(
            extracted_data=ExtractionResponse(**res.get("extracted_info", {})),
            potential_causes=[RootCauseItem(**c) for c in res.get("causes", [])],
            capas=[CAPAItem(**c) for c in res.get("capas", [])],
            missing_evidence=res.get("evidence_gaps", [])
        )
    except Exception as e:
        print(f"Groq workflow invocation error: {e}. Falling back to demonstration mode.")
        return get_demo_fallback()